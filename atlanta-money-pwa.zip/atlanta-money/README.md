# Atlanta Money (PWA)

A local-first personal finance tracker for iPhone. No bank connection, login, or age verification required.

## Features
- Mobile-first dashboard showing tracked income, expenses, and net cash flow (not bank balance)
- CSV transaction imports with preview, category rules, and duplicate skipping
- Manual transaction entry and deletion
- Three editable Atlanta savings goals
- JSON backup and restore
- Offline support after first visit via service worker

## Running
1. For testing on a computer, run `python3 -m http.server 8000` in this folder and open `http://localhost:8000`.
2. To install on iPhone, deploy these files to a private HTTPS static hosting site (for example GitHub Pages or Netlify), then open the HTTPS URL in Safari > Share > Add to Home Screen.
3. The app stores all financial data locally on the device. Hosting serves the app code, not your transactions. Don't upload your personal CSV files to the hosting provider.

## Import limitations
Cash App monthly statements are often PDF documents. This first version supports CSV only, including common columns for Date, Description, Amount, Credit, Debit, Type, and Status. It does not connect to Cash App or import PDFs directly. Check every import preview, since bank exports differ in how they label money in and out. Transfers may need manual categorization; imported cash-flow totals may not reflect actual earnings/spending. Duplicate detection uses date + description + amount, so genuinely identical transactions on the same day can be skipped. Export backups regularly; clearing browser data erases local records.

## Privacy
No third-party scripts, analytics, external APIs, or backend. All local data is stored in browser localStorage. Local storage is not encrypted and anyone with access to the unlocked device/browser profile may access it. Use iPhone device security and avoid shared devices.
